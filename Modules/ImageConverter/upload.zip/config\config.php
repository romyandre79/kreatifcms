<?php

return [
    'name' => 'ImageConverter',
];
